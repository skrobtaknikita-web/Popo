package com.example.heartopiaautodraw

/** Один жест: тап (x1,y1 == x2,y2) или свайп. pauseMs — дополнительная пауза после жеста (анимации интерфейса игры). */
data class Step(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val durMs: Long, val pauseMs: Long = 0) {
    val isSwipe: Boolean get() = x1 != x2 || y1 != y2
}

class PlanResult(
    val steps: List<Step>,
    /** Цвета, которые есть в рисунке, но для них не откалиброваны кнопка группы или слот оттенка — пропущены. */
    val missingColors: List<Int>,
    val cellsToPaint: Int
)

/**
 * Откалиброванные кнопки интерфейса игры. Ключи: g0..g12 — главные кнопки групп, shades — кнопка открытия
 * панели оттенков, back — «Назад» из панели оттенков, s1..s10 — слоты оттенков, brush / bucket — инструменты.
 */
class PaletteLayout {
    val points = LinkedHashMap<String, Pair<Float, Float>>()

    fun serialize(): String = points.entries.joinToString(";") { "${it.key}=${it.value.first.toInt()},${it.value.second.toInt()}" }

    companion object {
        fun parse(text: String?): PaletteLayout {
            val layout = PaletteLayout()
            text?.split(';', '\n')?.forEach { token ->
                val kv = token.trim().split('=')
                if (kv.size != 2) return@forEach
                val xy = kv[1].split(',')
                val x = xy.getOrNull(0)?.trim()?.toFloatOrNull(); val y = xy.getOrNull(1)?.trim()?.toFloatOrNull()
                if (x != null && y != null && kv[0].isNotBlank()) layout.points[kv[0].trim()] = x to y
            }
            return layout
        }
    }
}

/** Чистая логика (без Android): превращает сетку индексов палитры в последовательность жестов. */
object DrawPlan {
    /**
     * @param cells индекс палитры (1..125) для каждой клетки, построчно
     * @param firstX/firstY центр левой верхней клетки на экране; lastX/lastY — правой нижней
     * @param drag объединять соседние клетки одного цвета в строке в один свайп
     * @param skipIndex номер цвета, который не рисовать (белый холст); 0 — рисовать всё. Игнорируется при заливке.
     * @param uiPauseMs пауза после нажатий на кнопки интерфейса (группа/оттенки/инструменты)
     * @param useBucket сначала залить весь холст самым частым цветом (нужны откалиброванные bucket)
     */
    fun build(
        cells: IntArray, w: Int, h: Int,
        firstX: Float, firstY: Float, lastX: Float, lastY: Float,
        layout: PaletteLayout, drag: Boolean, skipIndex: Int, tapMs: Long, uiPauseMs: Long, useBucket: Boolean
    ): PlanResult {
        require(cells.size == w * h && w >= 2 && h >= 2)
        val stepX = (lastX - firstX) / (w - 1)
        val stepY = (lastY - firstY) / (h - 1)
        fun cx(x: Int) = firstX + x * stepX
        fun cy(y: Int) = firstY + y * stepY
        fun ui(p: Pair<Float, Float>) = Step(p.first, p.second, p.first, p.second, tapMs, uiPauseMs)

        val bucket = if (useBucket) layout.points["bucket"] else null
        val skip = if (bucket != null) 0 else skipIndex
        val counts = HashMap<Int, Int>()
        for (c in cells) if (c != skip) counts[c] = (counts[c] ?: 0) + 1

        // для заливки — самый частый цвет первым; дальше по группам, чтобы реже переключать панель
        val bucketColor = if (bucket != null) counts.maxByOrNull { it.value }?.key ?: 0 else 0
        val order = counts.keys.sortedWith(compareBy<Int>({ if (it == bucketColor) 0 else 1 }, { PaletteModel.groupOf(it) }, { -(counts[it] ?: 0) }))

        val steps = ArrayList<Step>()
        val missing = ArrayList<Int>()
        var painted = 0
        var curGroup = -1
        var panelOpen = false

        for (color in order) {
            val gi = PaletteModel.groupOf(color)
            val groupBtn = layout.points["g$gi"]
            val slotBtn = layout.points["s${PaletteModel.slotOf(color)}"]
            if (groupBtn == null || slotBtn == null) { missing.add(color); continue }

            if (curGroup != gi) {
                val back = layout.points["back"]
                if (panelOpen && back != null) steps.add(ui(back))
                steps.add(ui(groupBtn))
                layout.points["shades"]?.let { steps.add(ui(it)) }
                curGroup = gi; panelOpen = true
            }
            steps.add(ui(slotBtn))

            if (color == bucketColor && bucket != null) {
                steps.add(ui(bucket))
                steps.add(Step(cx(0), cy(0), cx(0), cy(0), tapMs, uiPauseMs))
                layout.points["brush"]?.let { steps.add(ui(it)) }
                painted += counts[color] ?: 0
                continue
            }
            for (y in 0 until h) {
                var x = 0
                while (x < w) {
                    if (cells[y * w + x] != color) { x++; continue }
                    var end = x
                    while (end + 1 < w && cells[y * w + end + 1] == color) end++
                    val len = end - x + 1
                    if (drag && len >= 2) steps.add(Step(cx(x), cy(y), cx(end), cy(y), maxOf(tapMs, len * 20L)))
                    else for (i in x..end) steps.add(Step(cx(i), cy(y), cx(i), cy(y), tapMs))
                    painted += len
                    x = end + 1
                }
            }
        }
        return PlanResult(steps, missing.sorted(), painted)
    }
}
