package com.example.heartopiaautodraw

import android.graphics.Bitmap
import android.graphics.Color

/** Результат конвертации: индекс палитры (1..125) для каждой клетки. */
class GridResult(val width: Int, val height: Int, val indices: IntArray) {
    fun argb(x: Int, y: Int): Int = PaletteModel.colors[indices[y * width + x] - 1].argb
    /** номер цвета -> число клеток */
    fun counts(): Map<Int, Int> = indices.toList().groupingBy { it }.eachCount()
}

object ImageProcessor {
    const val FIT_CROP = 0
    const val FIT_STRETCH = 1
    const val FIT_LETTERBOX = 2

    /** Подгоняет картинку под пропорции сетки: обрезка по центру, растяжение или белые поля. */
    fun fit(src: Bitmap, cols: Int, rows: Int, mode: Int): Bitmap {
        val target = cols.toFloat() / rows
        val aspect = src.width.toFloat() / src.height
        return when (mode) {
            FIT_STRETCH -> src
            FIT_LETTERBOX -> {
                val w = if (aspect > target) src.width else Math.round(src.height * target)
                val h = if (aspect > target) Math.round(src.width / target) else src.height
                val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = android.graphics.Canvas(out); c.drawColor(Color.WHITE)
                c.drawBitmap(src, ((w - src.width) / 2).toFloat(), ((h - src.height) / 2).toFloat(), null)
                out
            }
            else -> {
                if (aspect > target) {
                    val w = Math.round(src.height * target).coerceIn(1, src.width)
                    Bitmap.createBitmap(src, (src.width - w) / 2, 0, w, src.height)
                } else {
                    val h = Math.round(src.width / target).coerceIn(1, src.height)
                    Bitmap.createBitmap(src, 0, (src.height - h) / 2, src.width, h)
                }
            }
        }
    }

    fun convert(src: Bitmap, cols: Int, rows: Int, maxColors: Int, dither: Boolean): GridResult {
        val avg = boxDownscale(src, cols, rows) // 0xRRGGBB на белом фоне

        // 1) какие цвета палитры вообще нужны (топ-N по частоте)
        val firstPass = IntArray(avg.size) { PaletteModel.nearest(avg[it]).index }
        val counts = HashMap<Int, Int>()
        for (i in firstPass) counts[i] = (counts[i] ?: 0) + 1
        val chosen = counts.entries.sortedByDescending { it.value }.take(maxColors).map { it.key }.toSet()
        val subset = PaletteModel.colors.filter { it.index in chosen }

        // 2) финальное сопоставление в выбранном подмножестве (с дизерингом Флойда—Стейнберга по желанию)
        val out = IntArray(avg.size)
        if (!dither) {
            for (i in avg.indices) out[i] = PaletteModel.nearest(avg[i], subset).index
        } else {
            val r = FloatArray(avg.size) { Color.red(avg[it]).toFloat() }
            val g = FloatArray(avg.size) { Color.green(avg[it]).toFloat() }
            val b = FloatArray(avg.size) { Color.blue(avg[it]).toFloat() }
            for (y in 0 until rows) for (x in 0 until cols) {
                val i = y * cols + x
                val want = Color.rgb(r[i].toInt().coerceIn(0, 255), g[i].toInt().coerceIn(0, 255), b[i].toInt().coerceIn(0, 255))
                val p = PaletteModel.nearest(want, subset)
                out[i] = p.index
                val er = r[i] - Color.red(p.argb); val eg = g[i] - Color.green(p.argb); val eb = b[i] - Color.blue(p.argb)
                fun spread(nx: Int, ny: Int, k: Float) {
                    if (nx !in 0 until cols || ny !in 0 until rows) return
                    val j = ny * cols + nx
                    r[j] += er * k; g[j] += eg * k; b[j] += eb * k
                }
                spread(x + 1, y, 7f / 16); spread(x - 1, y + 1, 3f / 16); spread(x, y + 1, 5f / 16); spread(x + 1, y + 1, 1f / 16)
            }
        }
        return GridResult(cols, rows, out)
    }

    /** Усреднение по площади (нормальный «ресайз вниз», без рваных краёв); прозрачность — на белый фон. */
    private fun boxDownscale(src: Bitmap, cols: Int, rows: Int): IntArray {
        val sw = src.width; val sh = src.height
        val px = IntArray(sw * sh); src.getPixels(px, 0, sw, 0, 0, sw, sh)
        val out = IntArray(cols * rows)
        for (cy in 0 until rows) {
            val y0 = (cy.toLong() * sh / rows).toInt()
            val y1 = maxOf(y0 + 1, ((cy + 1).toLong() * sh / rows).toInt()).coerceAtMost(sh)
            for (cx in 0 until cols) {
                val x0 = (cx.toLong() * sw / cols).toInt()
                val x1 = maxOf(x0 + 1, ((cx + 1).toLong() * sw / cols).toInt()).coerceAtMost(sw)
                var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
                for (y in y0 until y1) for (x in x0 until x1) {
                    val c = px[y * sw + x]
                    val a = Color.alpha(c)
                    sr += (Color.red(c) * a + 255 * (255 - a)) / 255
                    sg += (Color.green(c) * a + 255 * (255 - a)) / 255
                    sb += (Color.blue(c) * a + 255 * (255 - a)) / 255
                    n++
                }
                out[cy * cols + cx] = Color.rgb((sr / n).toInt(), (sg / n).toInt(), (sb / n).toInt())
            }
        }
        return out
    }
}
