package com.example.heartopiaautodraw

import android.graphics.Color

data class PaletteColor(val index: Int, val hex: String, val argb: Int = Color.parseColor(hex))

object PaletteModel {
    // 125-color Heartopia Canvas palette published by Lospec; community-provided, not an official game API.
    val colors: List<PaletteColor> = listOf(
        PaletteColor(1, "#000000"),
        PaletteColor(2, "#404040"),
        PaletteColor(3, "#808080"),
        PaletteColor(4, "#bfbfbf"),
        PaletteColor(5, "#ffffff"),
        PaletteColor(6, "#d02f48"),
        PaletteColor(7, "#ef6c70"),
        PaletteColor(8, "#a61d39"),
        PaletteColor(9, "#f6aba5"),
        PaletteColor(10, "#ca8281"),
        PaletteColor(11, "#a35a5c"),
        PaletteColor(12, "#692934"),
        PaletteColor(13, "#e7d5d4"),
        PaletteColor(14, "#c0abaa"),
        PaletteColor(15, "#745c5c"),
        PaletteColor(16, "#e95b23"),
        PaletteColor(17, "#fa8155"),
        PaletteColor(18, "#ab3d1d"),
        PaletteColor(19, "#ffb99e"),
        PaletteColor(20, "#da927a"),
        PaletteColor(21, "#af6954"),
        PaletteColor(22, "#75362a"),
        PaletteColor(23, "#e9d5cf"),
        PaletteColor(24, "#c1aba5"),
        PaletteColor(25, "#755c57"),
        PaletteColor(26, "#f49d00"),
        PaletteColor(27, "#ffad36"),
        PaletteColor(28, "#b16c00"),
        PaletteColor(29, "#ffce90"),
        PaletteColor(30, "#dba66b"),
        PaletteColor(31, "#b37f46"),
        PaletteColor(32, "#794d1c"),
        PaletteColor(33, "#f6e3ce"),
        PaletteColor(34, "#cebba8"),
        PaletteColor(35, "#806c5c"),
        PaletteColor(36, "#eec900"),
        PaletteColor(37, "#fad831"),
        PaletteColor(38, "#b39300"),
        PaletteColor(39, "#fbe68f"),
        PaletteColor(40, "#d3bd6c"),
        PaletteColor(41, "#ab9446"),
        PaletteColor(42, "#74601f"),
        PaletteColor(43, "#efe6c6"),
        PaletteColor(44, "#c6bea1"),
        PaletteColor(45, "#786f57"),
        PaletteColor(46, "#a8bb00"),
        PaletteColor(47, "#b7c82b"),
        PaletteColor(48, "#748400"),
        PaletteColor(49, "#d8df92"),
        PaletteColor(50, "#adb66b"),
        PaletteColor(51, "#858f46"),
        PaletteColor(52, "#525b20"),
        PaletteColor(53, "#e6e9c6"),
        PaletteColor(54, "#bdc1a2"),
        PaletteColor(55, "#6e725a"),
        PaletteColor(56, "#00a15a"),
        PaletteColor(57, "#41b879"),
        PaletteColor(58, "#007243"),
        PaletteColor(59, "#9cd9ac"),
        PaletteColor(60, "#76b18a"),
        PaletteColor(61, "#4f8766"),
        PaletteColor(62, "#23523a"),
        PaletteColor(63, "#c4e0cb"),
        PaletteColor(64, "#9db6a5"),
        PaletteColor(65, "#53665a"),
        PaletteColor(66, "#00857f"),
        PaletteColor(67, "#00aa9f"),
        PaletteColor(68, "#006664"),
        PaletteColor(69, "#7eccc1"),
        PaletteColor(70, "#54a39b"),
        PaletteColor(71, "#2a7b76"),
        PaletteColor(72, "#004746"),
        PaletteColor(73, "#bfe0d9"),
        PaletteColor(74, "#98b6b1"),
        PaletteColor(75, "#4e6764"),
        PaletteColor(76, "#00709b"),
        PaletteColor(77, "#0098b9"),
        PaletteColor(78, "#005476"),
        PaletteColor(79, "#79baca"),
        PaletteColor(80, "#5192a4"),
        PaletteColor(81, "#246a7d"),
        PaletteColor(82, "#004558"),
        PaletteColor(83, "#c6dde2"),
        PaletteColor(84, "#9eb4b9"),
        PaletteColor(85, "#4f656c"),
        PaletteColor(86, "#005ba5"),
        PaletteColor(87, "#2981c0"),
        PaletteColor(88, "#004280"),
        PaletteColor(89, "#83a7c8"),
        PaletteColor(90, "#5d7ea0"),
        PaletteColor(91, "#34597d"),
        PaletteColor(92, "#123452"),
        PaletteColor(93, "#c2ccd5"),
        PaletteColor(94, "#9ba5af"),
        PaletteColor(95, "#4c5765"),
        PaletteColor(96, "#534aa0"),
        PaletteColor(97, "#7574bc"),
        PaletteColor(98, "#3e337b"),
        PaletteColor(99, "#a29fc7"),
        PaletteColor(100, "#7878a0"),
        PaletteColor(101, "#54527c"),
        PaletteColor(102, "#322d51"),
        PaletteColor(103, "#c9cad5"),
        PaletteColor(104, "#a2a2af"),
        PaletteColor(105, "#565566"),
        PaletteColor(106, "#81378a"),
        PaletteColor(107, "#a165a8"),
        PaletteColor(108, "#612469"),
        PaletteColor(109, "#b89ab8"),
        PaletteColor(110, "#907194"),
        PaletteColor(111, "#6c4a71"),
        PaletteColor(112, "#422746"),
        PaletteColor(113, "#d0c8d1"),
        PaletteColor(114, "#aba0ab"),
        PaletteColor(115, "#605262"),
        PaletteColor(116, "#ad2e6c"),
        PaletteColor(117, "#d0678e"),
        PaletteColor(118, "#861d55"),
        PaletteColor(119, "#daa0b3"),
        PaletteColor(120, "#b4788b"),
        PaletteColor(121, "#8b4f65"),
        PaletteColor(122, "#612d46"),
        PaletteColor(123, "#e4d5d9"),
        PaletteColor(124, "#bdacb0"),
        PaletteColor(125, "#725c63")
    )

    /** Группы кнопок в игре: 0 = чёрный/серый/белый (5 оттенков), 1..12 = цветные группы по 10 оттенков. */
    val groupNames = listOf("Чёрный/серый/белый", "Красный", "Оранжевый", "Янтарный", "Жёлтый", "Жёлто-зелёный",
        "Зелёный", "Бирюзовый", "Голубой", "Синий", "Индиго", "Фиолетовый", "Розовый")
    /** Цвет главной кнопки группы (по каталогу пресетов игры), только для подсказки при калибровке. */
    val groupButtonColors = listOf("#051616", "#EF6E72", "#F98358", "#FEAE3B", "#F9D837", "#B7C931", "#41B97B",
        "#05ABA0", "#0599BA", "#2B83C1", "#7577BC", "#A167A9", "#D0698F").map { Color.parseColor(it) }

    fun groupOf(index: Int): Int = if (index <= 5) 0 else (index - 6) / 10 + 1
    /** Номер оттенка внутри группы, 1..10 (для группы 0 — 1..5). */
    fun slotOf(index: Int): Int = if (index <= 5) index else (index - 6) % 10 + 1

    private val byArgb: Map<Int, PaletteColor> by lazy { colors.associateBy { it.argb } }

    fun byColor(argb: Int): PaletteColor? = byArgb[argb or (0xFF shl 24)]

    fun nearest(target: Int, available: List<PaletteColor> = colors): PaletteColor =
        available.minBy { distance(target, it.argb) }

    /** "Redmean": заметно ближе к восприятию, чем простое RGB-расстояние. */
    fun distance(a: Int, b: Int): Long {
        val rMean = (Color.red(a) + Color.red(b)) / 2
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return ((512 + rMean) * dr * dr shr 8).toLong() + 4L * dg * dg + ((767 - rMean) * db * db shr 8).toLong()
    }
}
