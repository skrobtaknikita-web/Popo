package com.example.heartopiaautodraw

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val reqPick = 101
    private val reqSavePng = 102
    private val reqSaveCsv = 103

    private var source: Bitmap? = null
    private var grid: GridResult? = null

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var preview: ImageView
    private lateinit var info: TextView
    private lateinit var calibInfo: TextView
    private lateinit var cols: EditText
    private lateinit var rows: EditText
    private lateinit var maxColors: EditText
    private lateinit var presetSpinner: Spinner
    private lateinit var fitSpinner: Spinner
    private lateinit var bucketMode: CheckBox
    private lateinit var uiPause: EditText
    private lateinit var dither: CheckBox
    private lateinit var dragMode: CheckBox
    private lateinit var skipWhite: CheckBox
    private lateinit var tapDelay: EditText
    private lateinit var countdown: EditText

    private val presets: List<Pair<String, Pair<Int, Int>?>> = listOf(
        "Свой размер" to null,
        "1:1 · 30×30" to (30 to 30), "1:1 · 50×50" to (50 to 50), "1:1 · 100×100" to (100 to 100), "1:1 · 150×150" to (150 to 150),
        "16:9 · 30×18" to (30 to 18), "16:9 · 50×28" to (50 to 28), "16:9 · 100×56" to (100 to 56), "16:9 · 150×84" to (150 to 84),
        "4:3 · 30×24" to (30 to 24), "4:3 · 50×38" to (50 to 38), "4:3 · 100×76" to (100 to 76), "4:3 · 150×114" to (150 to 114),
        "3:4 · 24×30" to (24 to 30), "3:4 · 38×50" to (38 to 50), "3:4 · 76×100" to (76 to 100), "3:4 · 114×150" to (114 to 150),
        "9:16 · 18×30" to (18 to 30), "9:16 · 28×50" to (28 to 50), "9:16 · 56×100" to (56 to 100), "9:16 · 84×150" to (84 to 150)
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ───────────────────────── UI ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(24)) }

        root.addView(text("Heartopia AutoDraw 0.6", 24f))
        info = text("1. Картинка  2. Преобразовать  3. Калибровка  4. Рисовать", 14f); root.addView(info)

        root.addView(button("Выбрать картинку") { pickImage() })
        preview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.LTGRAY) }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)))

        root.addView(text("Размер холста игры (подбери такой же, как на доске в игре)", 12f))
        presetSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, presets.map { it.first }) }
        root.addView(presetSpinner)
        val dims = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cols = number("Колонки", prefs.getString("cols", "30")!!); rows = number("Строки", prefs.getString("rows", "30")!!)
        dims.addView(cols, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        dims.addView(rows, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(dims)
        presetSpinner.setSelection(prefs.getInt("preset", 0))
        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                presets[pos].second?.let { (c, r) -> cols.setText(c.toString()); rows.setText(r.toString()) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(text("Как вписать картинку в холст", 12f))
        fitSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Обрезать по центру", "Растянуть", "Вписать с белыми полями"))
            setSelection(prefs.getInt("fit", 0))
        }
        root.addView(fitSpinner)
        maxColors = number("Максимум цветов", prefs.getString("maxColors", "16")!!); root.addView(maxColors)
        dither = check("Дизеринг (мягкие переходы, но больше шума)", prefs.getBoolean("dither", false)); root.addView(dither)
        root.addView(button("Преобразовать в пиксель-арт") { convert() })
        root.addView(button("Сохранить PNG") { if (ensureGrid()) createDocument("image/png", "heartopia-scheme.png", reqSavePng) })
        root.addView(button("Сохранить CSV (клетка → цвет)") { if (ensureGrid()) createDocument("text/csv", "heartopia-grid.csv", reqSaveCsv) })

        root.addView(text("Автоматическое рисование", 20f).apply { setPadding(0, dp(16), 0, 0) })
        root.addView(text("Если переключатель службы неактивен (APK не из магазина): Настройки → Приложения → Heartopia AutoDraw → ⋮ → «Разрешить ограниченные настройки».", 12f))
        root.addView(button("1) Включить службу специальных возможностей") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(button("2) Калибровка холста: 2 касания в игре") { calibrateGrid() })
        root.addView(text("Калибровка палитры игры в два этапа (один раз, дальше сохраняется):", 12f))
        root.addView(button("3a) Кнопки групп цвета (главный экран палитры)") { calibrateGroups() })
        root.addView(button("3b) Оттенки и «Назад» (открой панель оттенков в игре)") { calibrateShades() })
        calibInfo = text("", 13f); root.addView(calibInfo)
        root.addView(button("Сбросить калибровку палитры") { prefs.edit().remove("layout").apply(); refreshCalibInfo() })

        tapDelay = number("Задержка между нажатиями, мс", prefs.getString("delay", "80")!!); root.addView(tapDelay)
        uiPause = number("Пауза после кнопок палитры/инструментов, мс", prefs.getString("uiPause", "300")!!); root.addView(uiPause)
        countdown = number("Обратный отсчёт перед стартом, с", prefs.getString("countdown", "5")!!); root.addView(countdown)
        bucketMode = check("Сначала залить холст самым частым цветом инструментом «Заливка» (нужна калибровка кнопок «Заливка» и «Кисть» в 3a)", prefs.getBoolean("bucket", false)); root.addView(bucketMode)
        dragMode = check("Режим мазков: соседние клетки одного цвета одним свайпом (быстрее; проверь на малом холсте)", prefs.getBoolean("drag", false)); root.addView(dragMode)
        skipWhite = check("Не рисовать белый (№5), если холст уже белый (не действует при заливке)", prefs.getBoolean("skipWhite", false)); root.addView(skipWhite)

        root.addView(button("▶ Начать рисование") { startDrawing() })
        root.addView(button("⏸ Пауза / продолжить") { DrawAccessibilityService.instance?.togglePause() })
        root.addView(button("■ Остановить") { DrawAccessibilityService.instance?.stopPainting("Остановлено из приложения"); info.text = "Остановлено" })
        root.addView(text("Во время рисования поверх игры появится панель ⏸ / ■ — её можно перетащить за текст. Сначала проверь всё на сетке 4×4.", 12f))

        val scroll = ScrollView(this).apply { fitsSystemWindows = true; addView(root) }
        setContentView(scroll)
        refreshCalibInfo()
    }

    override fun onResume() {
        super.onResume()
        DrawAccessibilityService.statusListener = { msg -> runOnUiThread { info.text = msg } }
        refreshCalibInfo()
    }

    override fun onPause() {
        super.onPause()
        DrawAccessibilityService.statusListener = null
        saveFields()
    }

    private fun text(t: String, size: Float) = TextView(this).apply { text = t; textSize = size; setPadding(0, dp(4), 0, dp(4)) }
    private fun button(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }
    private fun number(hint: String, value: String) = EditText(this).apply { this.hint = hint; setText(value); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
    private fun check(t: String, value: Boolean) = CheckBox(this).apply { text = t; isChecked = value; textSize = 13f }

    private fun saveFields() {
        prefs.edit()
            .putString("cols", cols.text.toString()).putString("rows", rows.text.toString())
            .putInt("preset", presetSpinner.selectedItemPosition).putInt("fit", fitSpinner.selectedItemPosition)
            .putString("maxColors", maxColors.text.toString()).putString("delay", tapDelay.text.toString())
            .putString("uiPause", uiPause.text.toString()).putString("countdown", countdown.text.toString())
            .putBoolean("dither", dither.isChecked).putBoolean("bucket", bucketMode.isChecked)
            .putBoolean("drag", dragMode.isChecked).putBoolean("skipWhite", skipWhite.isChecked)
            .apply()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ───────────────────────── изображение ─────────────────────────

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(intent, reqPick)
    }

    /** Загружает картинку не крупнее ~2048 px по большей стороне, с учётом поворота из EXIF. */
    private fun decode(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val degrees = try {
            contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) { 0f }
        return if (degrees == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
    }

    private fun convert() {
        val src = source ?: run { toast("Сначала выбери картинку"); return }
        val c = (cols.text.toString().toIntOrNull() ?: 30).coerceIn(4, 150)
        val r = (rows.text.toString().toIntOrNull() ?: 30).coerceIn(4, 150)
        cols.setText(c.toString()); rows.setText(r.toString())
        val limit = (maxColors.text.toString().toIntOrNull() ?: 16).coerceIn(2, 125)
        val fitted = ImageProcessor.fit(src, c, r, fitSpinner.selectedItemPosition)
        val result = ImageProcessor.convert(fitted, c, r, limit, dither.isChecked)
        grid = result
        preview.setImageBitmap(render(result, if (c > 80 || r > 80) 6 else 12, c <= 60 && r <= 60))
        val counts = result.counts()
        info.text = buildString {
            append("Готово: $c × $r = ${c * r} клеток, цветов: ${counts.size} из 125\n")
            append("Цвета (№ HEX группа/оттенок — клеток):\n")
            counts.entries.sortedByDescending { it.value }.forEach { (idx, n) ->
                append("$idx  ${PaletteModel.colors[idx - 1].hex.uppercase()}  ${PaletteModel.groupOf(idx)}/${PaletteModel.slotOf(idx)} — $n\n")
            }
            append("\nПосле смены размера сетки калибровку холста (п.2) нужно повторить.")
        }
        refreshCalibInfo()
    }

    private fun ensureGrid(): Boolean { if (grid == null) convert(); return grid != null }

    private fun render(g: GridResult, scale: Int, lines: Boolean): Bitmap {
        val out = Bitmap.createBitmap(g.width * scale, g.height * scale, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out); val paint = Paint().apply { isAntiAlias = false }
        for (y in 0 until g.height) for (x in 0 until g.width) {
            paint.color = g.argb(x, y)
            canvas.drawRect((x * scale).toFloat(), (y * scale).toFloat(), ((x + 1) * scale).toFloat(), ((y + 1) * scale).toFloat(), paint)
        }
        if (lines) {
            paint.color = 0x55808080; paint.strokeWidth = 1f
            for (x in 0..g.width) canvas.drawLine((x * scale).toFloat(), 0f, (x * scale).toFloat(), out.height.toFloat(), paint)
            for (y in 0..g.height) canvas.drawLine(0f, (y * scale).toFloat(), out.width.toFloat(), (y * scale).toFloat(), paint)
        }
        return out
    }

    private fun makeCsv(): String {
        val g = grid ?: return ""
        return buildString {
            append("row,column,palette_index,hex\n")
            for (y in 0 until g.height) for (x in 0 until g.width) {
                val idx = g.indices[y * g.width + x]
                append("${y + 1},${x + 1},$idx,${PaletteModel.colors[idx - 1].hex}\n")
            }
        }
    }

    private fun createDocument(mime: String, name: String, request: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, name) }
        startActivityForResult(intent, request)
    }

    @Deprecated("Deprecated API kept for broad Android IDE compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            reqPick -> {
                val bmp = try { decode(uri) } catch (e: Exception) { null }
                if (bmp == null) { toast("Не удалось открыть изображение"); return }
                source = bmp; grid = null
                preview.setImageBitmap(bmp)
                info.text = "Изображение загружено (${bmp.width}×${bmp.height}). Нажми «Преобразовать»."
            }
            reqSavePng, reqSaveCsv -> try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (requestCode == reqSavePng) grid?.let { render(it, 16, false).compress(Bitmap.CompressFormat.PNG, 100, out) }
                    else out.write(makeCsv().toByteArray(Charsets.UTF_8))
                }
                toast("Файл сохранён")
            } catch (e: Exception) { toast("Ошибка сохранения: ${e.message}") }
        }
    }

    // ───────────────────────── калибровка ─────────────────────────

    private fun service(): DrawAccessibilityService? {
        val s = DrawAccessibilityService.instance
        if (s == null) {
            toast("Включи «Heartopia AutoDraw control» в настройках специальных возможностей и вернись сюда")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        return s
    }

    /** Две точки: центр первой клетки (верх-лево) и центр последней (низ-право) нарисованной области. */
    private fun calibrateGrid() {
        val g = grid ?: run { toast("Сначала преобразуй картинку: калибровка привязана к размеру сетки"); return }
        val s = service() ?: return
        saveFields()
        toast("Открой Heartopia на холсте. Слой калибровки уже поверх экрана.")
        val pts = FloatArray(4)
        s.startCapture(
            listOf(
                CapturePrompt("Коснись ЦЕНТРА клетки в левом верхнем углу рисунка (клетка 1,1)"),
                CapturePrompt("Коснись ЦЕНТРА клетки в правом нижнем углу рисунка (клетка ${g.width},${g.height})")
            ),
            onPoint = { i, x, y -> pts[i * 2] = x; pts[i * 2 + 1] = y },
            onFinish = { ok ->
                if (ok && pts[2] > pts[0] && pts[3] > pts[1]) {
                    prefs.edit().putFloat("fx", pts[0]).putFloat("fy", pts[1]).putFloat("lx", pts[2]).putFloat("ly", pts[3])
                        .putInt("calW", g.width).putInt("calH", g.height).apply()
                    runOnUiThread { info.text = "Сетка откалибрована"; refreshCalibInfo() }
                } else runOnUiThread { info.text = "Калибровка сетки отменена или точки заданы неверно (вторая должна быть правее и ниже первой)" }
            }
        )
    }

    private fun layout() = PaletteLayout.parse(prefs.getString("layout", ""))

    private fun usedGroupsAndSlots(g: GridResult): Pair<List<Int>, List<Int>> {
        val used = g.counts().keys
        return used.map { PaletteModel.groupOf(it) }.distinct().sorted() to used.map { PaletteModel.slotOf(it) }.distinct().sorted()
    }

    /** Этап 3a: главный экран палитры — кнопки групп, кнопка панели оттенков, инструменты. */
    private fun calibrateGroups() {
        val g = grid ?: run { toast("Сначала преобразуй картинку: нужны только кнопки используемых групп"); return }
        val s = service() ?: return
        saveFields()
        val (groups, _) = usedGroupsAndSlots(g)
        val keys = ArrayList<String>(); val prompts = ArrayList<CapturePrompt>()
        groups.forEach { gi -> keys.add("g$gi"); prompts.add(CapturePrompt("Главная кнопка группы «${PaletteModel.groupNames[gi]}»", PaletteModel.groupButtonColors[gi])) }
        keys.add("shades"); prompts.add(CapturePrompt("Кнопка, открывающая панель оттенков (если её нет в игре — «Пропустить»)"))
        if (bucketMode.isChecked) {
            keys.add("bucket"); prompts.add(CapturePrompt("Инструмент «Заливка» (ведро)"))
            keys.add("brush"); prompts.add(CapturePrompt("Инструмент «Кисть» (для возврата после заливки)"))
        }
        toast("Открой в игре экран палитры с главными кнопками цветов. Слой калибровки уже поверх экрана.")
        runCapture(s, keys, prompts, "Кнопки групп")
    }

    /** Этап 3b: открытая панель оттенков — слоты оттенков и кнопка «Назад». */
    private fun calibrateShades() {
        val g = grid ?: run { toast("Сначала преобразуй картинку"); return }
        val s = service() ?: return
        saveFields()
        val (_, slots) = usedGroupsAndSlots(g)
        val keys = ArrayList<String>(); val prompts = ArrayList<CapturePrompt>()
        keys.add("back"); prompts.add(CapturePrompt("Кнопка «Назад» из панели оттенков (если нет — «Пропустить»)"))
        slots.forEach { k -> keys.add("s$k"); prompts.add(CapturePrompt("Оттенок №$k в открытой панели (считая в том порядке, как в игре)")) }
        toast("Сначала открой в игре панель оттенков (любой группы), потом возвращайся — слой уже поверх.")
        runCapture(s, keys, prompts, "Оттенки")
    }

    private fun runCapture(s: DrawAccessibilityService, keys: List<String>, prompts: List<CapturePrompt>, title: String) {
        val layout = layout()
        s.startCapture(prompts,
            onPoint = { i, x, y -> layout.points[keys[i]] = x to y },
            onFinish = { ok ->
                prefs.edit().putString("layout", layout.serialize()).apply()
                runOnUiThread { info.text = if (ok) "$title: готово" else "$title: прервано (сохранено, что успели)"; refreshCalibInfo() }
            })
    }

    private fun refreshCalibInfo() {
        if (!::calibInfo.isInitialized) return
        val has = prefs.contains("fx")
        val l = layout().points
        calibInfo.text = (if (has) "Холст: откалиброван для ${prefs.getInt("calW", 0)}×${prefs.getInt("calH", 0)}" else "Холст: не откалиброван") +
            "\nКнопок групп: ${l.keys.count { it.startsWith("g") }}, оттенков: ${l.keys.count { it.length <= 3 && it.startsWith("s") && it != "s" }}" +
            ", «Назад»: ${if ("back" in l) "да" else "нет"}, панель оттенков: ${if ("shades" in l) "да" else "нет"}" +
            ", заливка: ${if ("bucket" in l) "да" else "нет"}" +
            "\nСлужба: " + (if (DrawAccessibilityService.instance != null) "включена" else "не включена")
    }

    // ───────────────────────── запуск ─────────────────────────

    private fun startDrawing() {
        val g = grid ?: run { toast("Сначала выбери картинку и преобразуй её"); return }
        saveFields()
        if (!prefs.contains("fx")) { toast("Сначала откалибруй холст (п.2)"); return }
        if (prefs.getInt("calW", 0) != g.width || prefs.getInt("calH", 0) != g.height) {
            toast("Размер сетки изменился (${prefs.getInt("calW", 0)}×${prefs.getInt("calH", 0)} → ${g.width}×${g.height}). Повтори калибровку холста."); return
        }
        val layout = layout()
        if (layout.points.isEmpty()) { toast("Откалибруй палитру (п.3a и 3b)"); return }
        if (bucketMode.isChecked && "bucket" !in layout.points) toast("Кнопка «Заливка» не откалибрована — заливка будет пропущена")
        val service = service() ?: return

        val plan = DrawPlan.build(
            g.indices, g.width, g.height,
            prefs.getFloat("fx", 0f), prefs.getFloat("fy", 0f), prefs.getFloat("lx", 0f), prefs.getFloat("ly", 0f),
            layout, dragMode.isChecked, if (skipWhite.isChecked) 5 else 0, 40L,
            (uiPause.text.toString().toLongOrNull() ?: 300L).coerceIn(0L, 3000L), bucketMode.isChecked
        )
        if (plan.missingColors.isNotEmpty()) toast("Не откалиброваны кнопки для цветов: ${plan.missingColors.joinToString()} — они будут пропущены")
        if (plan.steps.isEmpty()) { info.text = "Нечего рисовать: проверь калибровку палитры"; return }
        val delay = tapDelay.text.toString().toLongOrNull() ?: 80L
        val wait = (countdown.text.toString().toIntOrNull() ?: 5).coerceIn(0, 60)
        service.startPainting(plan.steps, delay, wait)
        info.text = "Шагов: ${plan.steps.size}, клеток: ${plan.cellsToPaint}. Открой в игре главный экран палитры и переключайся в игру."
    }
}
