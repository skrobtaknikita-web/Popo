package com.example.heartopiaautodraw

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class CapturePrompt(val text: String, val chipColor: Int? = null)

/**
 * Рисует жестами по командам пользователя. Пока идёт рисование, поверх игры висит маленькая панель
 * «Пауза / Стоп» (её можно перетащить за текст). Остановить можно и из приложения.
 */
class DrawAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val wm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    private var queue = ArrayDeque<Step>()
    private var total = 0
    private var done = 0
    private var running = false
    private var paused = false
    private var generation = 0
    private var delayMs = 80L
    private var failStreak = 0

    private var panelRoot: View? = null
    private var panelText: TextView? = null
    private var pauseButton: Button? = null
    private var captureRoot: View? = null

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopPainting("Прервано системой") }
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopPainting(null); cancelCapture(); if (instance === this) instance = null
        return super.onUnbind(intent)
    }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    private fun report(msg: String) { statusListener?.invoke(msg) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ───────────────────────── рисование ─────────────────────────

    fun startPainting(steps: List<Step>, delay: Long, countdownSec: Int) {
        if (steps.isEmpty()) { report("Нет шагов для рисования"); return }
        stopPainting(null)
        queue = ArrayDeque(steps); total = steps.size; done = 0; failStreak = 0
        delayMs = delay.coerceIn(30L, 2000L)
        running = true; paused = false
        showPanel()
        val gen = ++generation
        report("Старт через $countdownSec с: переключись в Heartopia. Шагов: $total")
        countdown(gen, countdownSec)
    }

    private fun countdown(gen: Int, left: Int) {
        if (gen != generation || !running || paused) return
        if (left <= 0) { pump(gen); return }
        setPanelText("Старт через $left с…")
        handler.postDelayed({ countdown(gen, left - 1) }, 1000)
    }

    private fun pump(gen: Int) {
        if (gen != generation || !running || paused) return
        val step = queue.removeFirstOrNull()
        if (step == null) { finish(); return }
        perform(step) { ok ->
            if (gen != generation) return@perform
            if (ok) failStreak = 0 else failStreak++
            if (failStreak >= 15) { stopPainting("Остановлено: система не принимает жесты"); return@perform }
            done++
            if (done % 25 == 0 || done == total) {
                val pct = done * 100 / total
                setPanelText("$pct%  ($done/$total)")
                if (done % 100 == 0) report("Прогресс: $pct% ($done из $total)")
            }
            handler.postDelayed({ pump(gen) }, delayMs + step.pauseMs)
        }
    }

    private fun perform(step: Step, onResult: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(step.x1, step.y1); if (step.isSwipe) lineTo(step.x2, step.y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, step.durMs.coerceAtLeast(1L)))
            .build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { onResult(true) }
            override fun onCancelled(g: GestureDescription?) { onResult(false) }
        }, null)
        if (!accepted) handler.post { onResult(false) }
    }

    private fun finish() {
        running = false
        setPanelText("Готово ✓")
        report("Готово: выполнено шагов $done из $total")
        val gen = generation
        handler.postDelayed({ if (!running && gen == generation) hidePanel() }, 4000)
    }

    fun pausePainting() {
        if (!running || paused) return
        paused = true; generation++
        setPanelText("Пауза  ($done/$total)"); pauseButton?.text = "▶"
        report("Пауза")
    }

    fun resumePainting() {
        if (!running || !paused) return
        paused = false
        val gen = ++generation
        pauseButton?.text = "⏸"
        report("Продолжаю")
        handler.postDelayed({ pump(gen) }, 400)
    }

    fun togglePause() { if (paused) resumePainting() else pausePainting() }

    fun stopPainting(message: String?) {
        val was = running
        running = false; paused = false; generation++
        queue.clear()
        handler.removeCallbacksAndMessages(null)
        hidePanel()
        if (was && message != null) report(message)
    }

    val isRunning: Boolean get() = running

    // ───────────────────────── панель управления поверх игры ─────────────────────────

    private fun showPanel() {
        hidePanel()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(80) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply { setColor(0xE6222222.toInt()); cornerRadius = dp(16).toFloat() }
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            text = "…"; setPadding(dp(6), dp(6), dp(10), dp(6))
        }
        val pause = Button(this).apply { text = "⏸"; minWidth = dp(44); minimumWidth = dp(44); setOnClickListener { togglePause() } }
        val stop = Button(this).apply { text = "■"; minWidth = dp(44); minimumWidth = dp(44); setOnClickListener { stopPainting("Остановлено кнопкой на панели") } }
        root.addView(label); root.addView(pause); root.addView(stop)

        label.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                        try { wm.updateViewLayout(root, lp) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })
        try { wm.addView(root, lp) } catch (e: Exception) { report("Не удалось показать панель: ${e.message}"); return }
        panelRoot = root; panelText = label; pauseButton = pause
    }

    private fun setPanelText(t: String) { panelText?.text = t }

    private fun hidePanel() {
        panelRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelRoot = null; panelText = null; pauseButton = null
    }

    // ───────────────────────── калибровка тапами ─────────────────────────

    /**
     * Показывает затемнённый слой на весь экран и по очереди записывает точки касания.
     * Игра под слоем касаний не получает. onPoint вызывается для каждого шага (index в prompts),
     * onFinish(true) — все шаги пройдены, false — отмена.
     */
    fun startCapture(prompts: List<CapturePrompt>, onPoint: (Int, Float, Float) -> Unit, onFinish: (Boolean) -> Unit) {
        if (running) { report("Сначала останови рисование"); return }
        cancelCapture()
        if (prompts.isEmpty()) { onFinish(true); return }
        var index = 0

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val frame = FrameLayout(this).apply { setBackgroundColor(0x44000000) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { setColor(0xEE222222.toInt()); cornerRadius = dp(12).toFloat() }
        }
        val chip = View(this)
        val text = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        bar.addView(chip, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        bar.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        frame.addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply { setMargins(dp(12), dp(48), dp(12), 0) })

        fun showPrompt() {
            val p = prompts[index]
            text.text = "(${index + 1}/${prompts.size}) ${p.text}"
            if (p.chipColor != null) { chip.visibility = View.VISIBLE; chip.setBackgroundColor(p.chipColor) } else chip.visibility = View.GONE
        }
        fun close(ok: Boolean) { cancelCapture(); onFinish(ok) }

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val skip = Button(this).apply { this.text = "Пропустить"; setOnClickListener { index++; if (index >= prompts.size) close(true) else showPrompt() } }
        val cancel = Button(this).apply { this.text = "Отмена"; setOnClickListener { close(false) } }
        buttons.addView(skip); buttons.addView(cancel)
        frame.addView(buttons, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(48) })

        frame.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) {
                onPoint(index, e.rawX, e.rawY)
                index++
                if (index >= prompts.size) close(true) else showPrompt()
            }
            true
        }
        showPrompt()
        try { wm.addView(frame, lp); captureRoot = frame } catch (e: Exception) { report("Не удалось показать слой калибровки: ${e.message}"); onFinish(false) }
    }

    fun cancelCapture() {
        captureRoot?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        captureRoot = null
    }

    companion object {
        @Volatile var instance: DrawAccessibilityService? = null
        @Volatile var statusListener: ((String) -> Unit)? = null
    }
}
